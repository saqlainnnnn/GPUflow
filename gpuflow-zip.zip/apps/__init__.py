"""GPUFlow application monorepo."""
