"""GPUaaS integration client."""
