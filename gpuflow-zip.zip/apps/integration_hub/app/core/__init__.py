"""Application configuration and infrastructure."""
