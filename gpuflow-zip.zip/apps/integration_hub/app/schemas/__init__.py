"""Application schemas."""
