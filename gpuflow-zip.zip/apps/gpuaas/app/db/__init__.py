"""GPUaaS database infrastructure."""
