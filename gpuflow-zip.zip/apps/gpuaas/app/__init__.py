"""GPUaaS application."""
