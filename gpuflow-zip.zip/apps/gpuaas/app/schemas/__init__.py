"""GPUaaS schemas."""
